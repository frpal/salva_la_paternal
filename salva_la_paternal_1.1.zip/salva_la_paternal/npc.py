import items

class NonPlayableCharacter():
    def __init__(self):
        raise NotImplementedError("no vale crear NPCs.")
    
    def __str__(self):
        return self.name

class Polirrubro(NonPlayableCharacter):
    def __init__(self):
        self.name = "Polirrubro"
        self.pesos = 100
        self.inventory = [items.ChoriPan(),
                          items.PanDuro(),
                          items.PanDuro(),
                          items.Birra(),
                          items.Birra(),
                          items.Tramontina()]
        
class Churrero(NonPlayableCharacter):
    def __init__(self):
        self.name = "Churrero"
        self.pesos = 100
        self.inventory = [items.Churro(),
                          items.BolaFraile(),
                          items.Churro(),
                          items.BolaFraile(),
                          items.Churro(),
                          items.BolaFraile(),]

class Gitana(NonPlayableCharacter):
    def __init__(self):
        self.name = "Gitana"
        self.pesos = 5
        self.inventory = [items.BolaDeCristal(),
                          items.Pañuelo(),
                          items.DagaCeremonial()]

class BarraBicho(NonPlayableCharacter):
    def __init__(self):
        self.name = "Barra del Bicho"
        self.pesos = 10000
        self.inventory = [items.Birra(),
                          items.ChoriPan(),
                          items.Birra(),
                          items.ChoriPan(),
                          items.Birra(),
                          items.ChoriPan(),
                          items.Birra(),
                          items.ChoriPan()]