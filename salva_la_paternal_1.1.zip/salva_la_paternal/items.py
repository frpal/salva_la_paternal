import random

#items

class arma:
    def __init__(self):
        raise NotImplementedError("no vale crear armas")
    
    def __str__(self):
        return self.name

class Piedra(arma):
    def __init__(self):
        self.name = "piedra"
        self.description = "una piedra del tamaño de un puño grandote, sirve para noquear gente y animales."
        self.dmg = random.randint(4, 7)
        self.value = 2

class Palo(arma):
    def __init__(self):
        self.name = "palo"
        self.description = "un palo de escoba, tiene unos 1.6 mts de largo, sirve para ataques a distancia."
        self.dmg = random.randint(5, 8)
        self.value = 3

class Cinto(arma):
    def __init__(self):
        self.name = "cinto"
        self.description = "un cinto de cuero marrón medio curtido, con una ebilla de bronce pesada, mide unos 80 cm."
        self.dmg = random.randint(7, 10)
        self.value = 7

class Tramontina(arma):
    def __init__(self):
        self.name = "tramontina"
        self.description = "típicamente usado para la cocina, el tramontina es el mejor amigo del aventurero callejero."
        self.dmg = random.randint(18, 22)
        self.value = 30
        
class DagaCeremonial(arma):
    def __init__(self):
        self.name = "Daga Ceremonial"
        self.description = "una daga de ceremonias gitana"
        self.dmg = random.randint(25, 45)
        self.value = 200


class consumible:
    def __init__(self):
        raise NotImplementedError("no vale crear objetos sin subclase")
    
    def __str__(self):
        return "{} (+ {} HP".format(self.name, self.healing_value)
    
class Churro(consumible):
    def __init__(self):
        self.name = "churro relleno"
        self.healing_value = random.randint(8, 12)
        self.value = 2

class BolaFraile(consumible):
    def __init__(self):
        self.name = "bola de fraile"
        self.healing_value = random.randint(8, 12)
        self.value = 2

class PanDuro(consumible):
    def __init__(self):
        self.name = "pan duro"
        self.healing_value = random.randint(6, 10)
        self.value = 1
        
class ChoriPan(consumible):
    def __init__(self):
        self.name = "choripan"
        self.healing_value = random.randint(30, 50)
        self.value = 5
        
class Birra(consumible):
    def __init__(self):
        self.name = "birra"
        self.healing_value = random.randint(-5, 20)
        self.value = 2
        
class CarneCruda(consumible):
    def __init__(self):
        self.name = "carne cruda"
        self.healing_value = random.randint(-10, 10)
        self.value = 1

class Pizza(consumible):
    def __init__(self):
        self.name = "porción de muza"
        self.healing_value = random.randint(10, 18)
        self.value = 15
        
class Champan(consumible):
    def __init__(self):
        self.name = "champan"
        self.healing_value = random.randint(-15, 5)
        self.value = 100        

class inútil:
    def __init__(self):
        raise NotImplementedError("no vale crear inútiles")
    
    def __str__(self):
        return self.name

class Pañuelo(inútil):
    def __init__(self):
        self.name = "pañuelo"
        self.value = 70
        
class BolaDeCristal(inútil):
    def __init__(self):
        self.name = "Bola de Cristal"
        self.value = 150
        

    



    