#importo mis librerías:

from collections import OrderedDict
from player import Player
import world

#play part

def play():
    print("""

  ██████  ▄▄▄       ██▓  ██▒   █▓ 
▄▄▄          ██▓    ▄▄▄          ██▓███   ▄▄▄     ▄▄▄█████▓▓█████  ██▀███   ███▄    █  ▄▄▄       ██▓    
▒██    ▒ ▒████▄    ▓██▒ ▓██░   █▒▒████▄       ▓██▒   ▒████▄       ▓██░  ██▒▒████▄   ▓  ██▒ ▓▒▓█   ▀ ▓██ ▒ ██▒ ██ ▀█   █ ▒████▄    ▓██▒    
░ ▓██▄   ▒██  ▀█▄  ▒██░  ▓██  █▒░▒██  ▀█▄     ▒██░   ▒██  ▀█▄     ▓██░ ██▓▒▒██  ▀█▄ ▒ ▓██░ ▒░▒███   ▓██ ░▄█ ▒▓██  ▀█ ██▒▒██  ▀█▄  ▒██░    
  ▒   ██▒░██▄▄▄▄██ ▒██░   ▒██ █░░░██▄▄▄▄██    ▒██░   ░██▄▄▄▄██    ▒██▄█▓▒ ▒░██▄▄▄▄██░ ▓██▓ ░ ▒▓█  ▄ ▒██▀▀█▄  ▓██▒  ▐▌██▒░██▄▄▄▄██ ▒██░    
▒██████▒▒ ▓█   ▓██▒░██████▒▒▀█░   ▓█   ▓██▒   ░██████▒▓█   ▓██▒   ▒██▒ ░  ░ ▓█   ▓██▒ ▒██▒ ░ ░▒████▒░██▓ ▒██▒▒██░   ▓██░ ▓█   ▓██▒░██████▒
▒ ▒▓▒ ▒ ░ ▒▒   ▓▒█░░ ▒░▓  ░░ ▐░   ▒▒   ▓▒█░   ░ ▒░▓  ░▒▒   ▓▒█░   ▒▓▒░ ░  ░ ▒▒   ▓▒█░ ▒ ░░   ░░ ▒░ ░░ ▒▓ ░▒▓░░ ▒░   ▒ ▒  ▒▒   ▓▒█░░ ▒░▓  ░
░ ░▒  ░ ░  ▒   ▒▒ ░░ ░ ▒  ░░ ░░    ▒   ▒▒ ░   ░ ░ ▒  ░ ▒   ▒▒ ░   ░▒ ░       ▒   ▒▒ ░   ░     ░ ░  ░  ░▒ ░ ▒░░ ░░   ░ ▒░  ▒   ▒▒ ░░ ░ ▒  ░
░  ░  ░    ░   ▒     ░ ░     ░░    ░   ▒        ░ ░    ░   ▒      ░░         ░   ▒    ░         ░     ░░   ░    ░   ░ ░   ░   ▒     ░ ░   
      ░        ░  ░    ░  ░   ░        ░  ░       ░  ░     ░  ░                  ░  ░           ░  ░   ░              ░       ░  ░    ░  ░
                             ░                                                                                                            

""")
    world.parse_world_dsl()
    player = Player()
    while player.is_alive() and not player.victory:
        room = world.tile_at(player.x, player.y)
        print(room.intro_text())
        room.modify_player(player)
        if player.is_alive() and not player.victory:
            choose_action(room, player)
        elif not player.is_alive():
            print("te cagaste muriendo y nadie salvó la Paternal...")
        
def choose_action(room, player):
    action = None
    while not action:
        available_actions = get_available_actions(room, player)
        action_input = input("Acción: ")
        action = available_actions.get(action_input)
        if action:
            action()
        else:
            print("Acción inválida!")
            
def get_available_actions(room, player):
    actions = OrderedDict()
    print("Elegí una acción: ")
    if player.inventory:
        action_adder(actions, 'i', player.print_inventory, "Imprimir Inventario")
    if isinstance(room, world.PolirrubroTile):
        action_adder(actions, 'p', player.trade, "Polirrubro")
    if isinstance(room, world.GitanaRoom):
        action_adder(actions, 'g', player.trade, "Gitana")
    if isinstance(room, world.ChurroTile):
        action_adder(actions, 'ch', player.trade, "Churrero")
    if isinstance(room, world.EnemyTile) and room.enemy.is_alive():
        action_adder(actions, 'a', player.attack, "Atacar")
    if isinstance(room, world.MenemTile) and room.enemy.is_alive():
        action_adder(actions, 'a', player.attack, "Atacar")
    
    else:
        if world.tile_at(room.x, room.y - 1):
            action_adder(actions, 'n', player.move_north, "Ir al norte")
        if world.tile_at(room.x, room.y + 1):
            action_adder(actions, 's', player.move_south, "Ir al sur")
        if world.tile_at(room.x + 1, room.y):
            action_adder(actions, 'e', player.move_east, "Ir al este")
        if world.tile_at(room.x - 1, room.y):
            action_adder(actions, 'o', player.move_west, "Ir al oeste")
    if player.hp < 100:
        action_adder(actions, 'c', player.heal, "Curar")

    return actions

def action_adder(action_dict, hotkey, action, name):
    action_dict[hotkey.lower()] = action
    action_dict[hotkey.upper()] = action
    print("{}: {}".format(hotkey, name))


play()
