import random
import items

#enemigos
class enemy:
    def __init__(self):
        raise NotImplementedError("no vale crear enemigos sin subclase")
    
    def __str__(self):
        return self.name
    
    def is_alive(self):
        return self.hp > 0
    
class ManadaDeRatas(enemy):
    def __init__(self):
        self.name = "Manada de Ratas"
        self.description = """
        Si, una manada de ratas enojadas te atacan.
        """
        self.hp = 40
        self.dmg = random.randint(2, 8)
        self.inventory = [items.CarneCruda()]
    
class Fisura(enemy):
    def __init__(self):
        self.name = "Fisura"
        self.description = """
            el fisura del barrio, siempre chimborra,
            siempre violento, infumable.
            """
        self.hp = 10
        self.dmg = random.randint(3, 6)
        self.inventory = [items.Birra()]
        
class ViejxGorila(enemy):
    def __init__(self):
        self.name = "ViejxGorila"
        self.description = """
            todo barrio tiene su cuota de viejxs gorilas,
            cogotudxs, opinólogxs,
            nunca seas unx viejx gorila.
            """
        self.hp = 15
        self.dmg = random.randint(1, 5)
        self.inventory = [items.Palo()]
        
class Yuta(enemy):
    def __init__(self):
        self.name = "Yuta"
        self.description = """
            la yuta, todo mal con la yuta.
            """
        self.hp = 25
        self.dmg = random.randint(5, 10)
        self.inventory = [items.ChoriPan()]
        
class BarraPlatense(enemy):
    def __init__(self):
        self.name = "Barra de Platense"
        self.description = """
            estas en el barrio del bicho,
            ver a la barra de platense nunca
            trae buenas noticias.
            """
        self.hp = 50
        self.dmg = random.randint(8, 15)
        self.inventory = [items.Palo(),
                          items.ChoriPan(),
                          items.Birra()]
class CarlosMenem(enemy):
    def __init__(self):
        self.name = "Carlitos Menem"
        self.description = """
            Carlitos Menem, te caga a patadas antes de
            que el trasbordador vuelva de la estratósfera.
            """
        self.hp = 50
        self.dmg = random.randint(15, 35)
        self.inventory = [items.Champan(),
                          items.Pizza()]