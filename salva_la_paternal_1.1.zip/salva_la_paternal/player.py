#data del jugador
import items
import world

class Player:
    def __init__(self):
        self.inventory = [items.Palo(),
                          items.Cinto(),
                          items.PanDuro()]
        self.x = world.start_tile_location[0]
        self.y = world.start_tile_location[1]
        self.hp = 100
        self.pesos = 5
        self.victory = False
    
    def is_alive(self):
        return self.hp > 0

    def print_inventory(self):
        print("Inventario: ")
        for item in self.inventory:
            print("    *" + str(item))
        print("HP: {}".format(self.hp))
        print("Pesos: {}".format(self.pesos))
        best_wpn = self.most_pow_wpn()
        print("Tu mejor arma es tu {} ".format
        (best_wpn))

    def heal(self):
        consumibles = [item for item in self.inventory
                       if isinstance(item, items.consumible)]
        if not consumibles:
            print("no tenes nada con que curarte")
            return
        
        for i, item in enumerate(consumibles, 1):
            print("elegi un objeto para curarte: ")
            print("{}. {}".format(i, item))
        
        valid = False
        while not valid:
            choice = input("")
            try:
                to_eat = consumibles[int(choice) - 1]
                self.hp = min(100, self.hp + to_eat.healing_value)
                self.inventory.remove(to_eat)
                print("Puntos de vida actuales: {}".format(self.hp))
                valid = True
            except (ValueError, IndexError):
                print("elección inválida, intentá de nuevo.")
    
    

    def most_pow_wpn(self):
        max_dmg = 0
        best_wpn = None
        for item in self.inventory:
            try:
                if item.dmg > max_dmg:
                    best_wpn = item
                    max_dmg = item.dmg
            except AttributeError:
                pass
            
        return best_wpn

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def move_north(self):
        self.move(dx=0, dy=-1)

    def move_south(self):
        self.move(dx=0, dy=1)

    def move_east(self):
        self.move(dx=1, dy=0)

    def move_west(self):
        self.move(dx=-1, dy=0)
    
    def attack(self):
        best_wpn = self.most_pow_wpn()
        room = world.tile_at(self.x, self.y)
        enemy = room.enemy
        print("Usas tu {} contra {}!".format(best_wpn.name, enemy.name))
        enemy.hp -= best_wpn.dmg
        if not enemy.is_alive():
            print("{} la quedó!".format(enemy.name))
        else:
            print("Le quedan {} puntos de vida a {}.".format(enemy.hp, enemy.name))
            
    def trade(self):
        room = world.tile_at(self.x, self.y)
        room.check_if_trade(self)
        