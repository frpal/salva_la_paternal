import random
import enemies
import npc
import items

#worls module

class MapTile:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def intro_text(self):
        raise NotImplementedError("crea una subclase!")

    def modify_player(self, player):
        pass

class StartTile(MapTile):
    def intro_text(self):
        return """
        Apareces tirado en una esquina desierta
        de la Paternal, pero no sabes bien cual,
        """

class MenemTile(MapTile):
    def __init__(self, x, y):
        self.enemy = enemies.CarlosMenem()
        self.alive_text = "Si, Carlitos Menem, en la Paternal, mirándote fijo, huele a champán"
        self.dead_text = "Carlitos se esfuma misteriosamente en la niebla invernal, escuchás su risa espantosa a lo lejos"
    
        super().__init__(x, y)
    
    def intro_text(self):        
        if self.enemy.is_alive():
            text = self.alive_text 
        else:
            text = self.dead_text
        return text
    
    def modify_player(self, player):
        if self.enemy.is_alive():
            player.hp = player.hp - self.enemy.dmg
            print("{} te hace {} de daño! Te quedan {} puntos de vida.".
                    format(self.enemy.name, self.enemy.dmg, player.hp)) 


class EnemyTile(MapTile):
    def __init__(self, x, y):
        r = random.random()
        if r < 0.50:
            self.enemy = enemies.ViejxGorila()
            self.alive_text = """
                              te topas con un viejo gorila gritando:
                              'se robaron todo!!!'
                              se te pone a gritar y no te deja seguir caminando
                              """
            self.dead_text = """
                            el viejo gorila queda en el piso puteando, ya no puede pelear
                            """
        
        elif r < 0.75:
            self.enemy = enemies.Fisura()
            self.alive_text = """
                            te cruzas con un fisura que te gedentea para que le des unos mangos pal vino
                            """
            self.dead_text = """
                            el fisrua se caga encima y empieza a vomitar, ya no puede pelear
                            """
            
        elif r < 0.95:
            self.enemy = enemies.Yuta()
            self.alive_text = """
                            un rati te frena mientras caminas y te pide sin motivo el documento,
                            como no tenes te empieza a forcejear e intenta llevarte detenido
                            """
            self.dead_text = """
                            el rati se cansa, sus 6 meses de entrenamiento no fueron suficientes para derrotarte
                            """
        
        elif r < 98:
            self.enemy = enemies.ManadaDeRatas()
            self.alive_text = """
                            una manada de ratas te ataca
                            """
            self.dead_text = """
                            ves la manada de ratas reventada en el asfalto de la ochava,
            
                            la sangre drena a la boca de tormenta
                             """
            
        else:
            self.enemy = enemies.BarraPlatense()
            self.alive_text = """
                            aparece la barra de platense rodeandote, mal día para salir con la camiseta del bicho
                            """
            self.dead_text = """
                            los barras salen rajando ante tu innegable defensa de la Pater
                            """
        
        super().__init__(x, y)

    def intro_text(self):        
        if self.enemy.is_alive():
            text = self.alive_text 
        else:
            text = self.dead_text
        return text
        
    
    def modify_player(self, player):
        if self.enemy.is_alive():
            player.hp = player.hp - self.enemy.dmg
            print("{} te hace {} de daño! Te quedan {} puntos de vida.".
                    format(self.enemy.name, self.enemy.dmg, player.hp))
        
            


class VictoryTile(MapTile):
    def modify_player(self, player):
        player.victory = True
        
    def intro_text(self):
        return """
        encontraste el mejor lomito
        de la Paternal y salvaste a los
        jubilados de morir sin haberlo probado,
        Felicitaciones!
        Sos lx nuevx ídolx de la Pater!
        """

class GuitaTile(MapTile):
    def __init__(self, x, y):
        self.pesos = random.randint(1, 50)
        self.pesos_claimed = False
        super().__init__(x, y)
    
    def intro_text(self):
        if self.pesos_claimed:
            return """
            Otra esquina desierta en la Pater
            """
        else:
            """
            Te encontras unos mangos y te los guardas en el bolsillo.
            """
    
    def modify_player(self, player):
        if not self.pesos_claimed:
            self.pesos_claimed = True
            player.pesos = player.pesos + self.pesos
            print("te encontraste {} pesos!".format(self.pesos))


class ItemTile(MapTile):
    def __init__(self, x, y, item):
        self.item = item
        self.item_claimed = False
        super().__init__(x, y)
 
    def add_loot(self, player):
        player.inventory.append(self.item)
 
    def modify_player(self, player):
        if not self.item_claimed:
            self.item_claimed = True
            self.add_loot(player)
        
class ChoriRoom(ItemTile):
    def __init__(self, x, y):
        super().__init__(x, y, items.ChoriPan())
 
    def intro_text(self):
        if self.item_claimed:
            return """
            aca no hay nada
            """
        else:
            return """
        Te encontras un choripan calentito sobre una mesa abandonada
        en un restobar.
        """

class BirraRoom(ItemTile):
    def __init__(self, x, y):
        super().__init__(x, y, items.Birra())
 
    def intro_text(self):
        if self.item_claimed:
            return """
            aca no hay nada
            """
        else:
            return """
        Te encontras una birra tibia en el marco de una ventana
        Medio un asco, pero anda a saber cuando vas a conseguir una fría.
        """
        

class OtherTile(MapTile):
    def intro_text(self):
        return """
        este es otra esquina cualquiera de la
        Paternal...
        """

class LimiteEste(MapTile):
    def intro_text(self):
        return """
        Te topas con un vallado policial que
        
        se extiende sobre Juan B. Justo,
        
        hasta donde llega la vista,
        
        estás solx, no tenés chance.
        """
class LimiteOeste(MapTile):
    def intro_text(self):
        return """
        Estas a una cuadra y ya sentis el calor en la cara,
        
        El predio completo de la facultad de agronomía está en llamas,
        
        nunca habías visto un incendio de semejante tamaño
        
        mejor alejarse.
        """
class LimiteSur(MapTile):
    def intro_text(self):
        return """
        Quién te juna Villa Mitre?
        
        Nada que hacer x acá.
        """
class LimiteNorte(MapTile):
    def intro_text(self):
        return """
        Te topás con el implacable paredón del cementerio de Chacarita
        
        parece estar cubierto de rasguños ensangrentados.
        
        sobre la pared ves una serie de letras aparentemente sin sentido:
        
        0AA DEHC-AGBG // 17-12.1.27.1 17-1.17.17.16
        
        andá a saber.
        """
class BichoQuest(MapTile):
    def __init__(self, x, y):
        self.barrabicho = npc.BarraBicho()
        super().__init__(x, y)
    

class GitanaRoom(MapTile):
    def __init__(self, x, y):
        self.gitana = npc.Gitana()
        super().__init__(x, y)

    def check_if_trade(self, player):
        while True:
            print("""
                Pibe! Me vas a (C)omprar, (V)ender o te vas a (T)omar el palo?
                """)
            user_input = input()
            if user_input in ["T", "t"]:
                return
            elif user_input in ["C", "c"]:
                print(""""
                es lo que hay, por ahora...
                """)
                self.trade(buyer=player, seller=self.gitana)
            elif user_input in ["V", "v"]:
                print("""
                pf, que me vas a vender vos?
                """)
                self.trade(buyer=self.gitana, seller=player)
            else:
                print("""
                no te hagas el vivo pibe que te comés una macumba de la gran flauta...
                """)
            
            

    def trade(self, buyer, seller):
        for i, item in enumerate(seller.inventory, 1):
            print("{}. {} - {}Pesos".format(i, item.name,
            item.value))
        while True:
            user_input = input("ahora (T)omatelas")
            if user_input in ["T", "t"]:
                return
            else:
                try:
                    choice = int(user_input)
                    to_swap = seller.inventory[choice - 1]
                    self.swap(seller, buyer, to_swap)
                except ValueError:
                    print("no te hagas el vivo pibe.")

    def swap(self, seller, buyer, item):
        if item.value > buyer.pesos:
            print("Que me querés tomar el pelo? tocá de acá pibe.")
            return
        seller.inventory.remove(item)
        buyer.inventory.append(item)
        seller.pesos = seller.pesos + item.value
        buyer.pesos = buyer.pesos - item.value
        print("listo pibe, volvé con guita la próxima")
        
    def intro_text(self):
        return """
            -Pibe!
            -Pibe!
            
            Escuchás que te gritan del otro lado de la calle, te das vuelta para ver una gitana vieja y requecha
            caminando encorvada. Lleva un pañuelo azul oscuro que le cubre la cabeza y una pollera violeta
            que llega hasta el piso.
            
            -Vení un segundito que te quiero mostrar algo!
            """

class ChurroTile(MapTile):
    def __init__(self, x, y):
        self.churrero = npc.Churrero()
        super().__init__(x, y)

    def check_if_trade(self, player):
        while True:
            print("""
                Como andas tanto tiempo?
                Querés: (C)omprar o (I)rte?
                """)
            user_input = input()
            if user_input in ["I", "i"]:
                return
            elif user_input in ["C", "c"]:
                print(""""
                tengo lo de siempre, churros rellenos y bolas de fraile.
                """)
                self.trade(buyer=player, seller=self.churrero)
            elif user_input in ["V", "v"]:
                print("""
                a ver, qué me querés vender?
                """)
                self.trade(buyer=self.churrero, seller=player)
            else:
                print("""
                jaja que? no entendi.
                """)
            
            

    def trade(self, buyer, seller):
        for i, item in enumerate(seller.inventory, 1):
            print("{}. {} - {}Pesos".format(i, item.name,
            item.value))
        while True:
            user_input = input("qué vas a llevar? sino apreta la Q que me tengo que ir.")
            if user_input in ["Q", "q"]:
                return
            else:
                try:
                    choice = int(user_input)
                    to_swap = seller.inventory[choice - 1]
                    self.swap(seller, buyer, to_swap)
                except ValueError:
                    print("eh? no entendí.")

    def swap(self, seller, buyer, item):
        if item.value > buyer.pesos:
            print("No amigo, no puedo fiar más ya")
            return
        seller.inventory.remove(item)
        buyer.inventory.append(item)
        seller.pesos = seller.pesos + item.value
        buyer.pesos = buyer.pesos - item.value
        print("listo wachin, saludos a la flia")
        
    def intro_text(self):
        return """
            churrooooooos! *silbato*
            chuuuuuurroooooos *silbato*
            """

class PolirrubroTile(MapTile):
    def __init__(self, x, y):
        self.polirrubro = npc.Polirrubro()
        super().__init__(x, y)

    def check_if_trade(self, player):
        while True:
            print("""
                Bienvenido al polirrubro, no te siguieron... no?
                Más te vale..
                Querés: (C)omprar, (V)ender o (T)omartelas?
                """)
            user_input = input()
            if user_input in ["T", "t"]:
                return
            elif user_input in ["C", "c"]:
                print(""""
                es lo que hay, por ahora...
                """)
                self.trade(buyer=player, seller=self.polirrubro)
            elif user_input in ["V", "v"]:
                print("""
                a ver, qué me querés vender?
                """)
                self.trade(buyer=self.polirrubro, seller=player)
            else:
                print("""
                no te hagas el vivo...
                """)
            
            

    def trade(self, buyer, seller):
        for i, item in enumerate(seller.inventory, 1):
            print("{}. {} - {}Pesos".format(i, item.name,
            item.value))
        while True:
            user_input = input("elegí un objeto o apreta la Q para salir: ")
            if user_input in ["Q", "q"]:
                return
            else:
                try:
                    choice = int(user_input)
                    to_swap = seller.inventory[choice - 1]
                    self.swap(seller, buyer, to_swap)
                except ValueError:
                    print("elección inválida!")

    def swap(self, seller, buyer, item):
        if item.value > buyer.pesos:
            print("Noo jaja no, no. No te alcanza papá")
            return
        seller.inventory.remove(item)
        buyer.inventory.append(item)
        seller.pesos = seller.pesos + item.value
        buyer.pesos = buyer.pesos - item.value
        print("listo vieja, volvé con mas guita la próxima")
        
    def intro_text(self):
        return """
            Encontras un viejo polirrubro del barrio,
            pareciera que el tiempo no pasó por esta esquina,
            el piso esta pegajoso de cerveza vieja y huele a
            fiambre mezclado con humo de tabaco negro.
            Adentro, un viejo de bigote ancho cuenta unas monedas
            mientras fuma su cigarro. Sobre la mesa,  un chopp de cerveza
            transpira helada sobre la madera vieja.
            """
    
class BoringTile(MapTile):
    def intro_text(self):
        return """
        Esta es una esquina muy aburrida
        de la Paternal
        """


      


world_dsl = """

|  |  |  |  |  |  |LN|LN|LN|LN|LN|
|VT|ET|GT|  |  |  |GT|ET|OT|ET|LE|
|  |  |MT|ET|CR|ET|GT|ET|OT|BR|LE|
|  |GT|ET|CR|BT|BT|GT|ET|OT|GT|LE|
|LO|BT|GT|BT|GT|ET|ET|CR|GT|ET|LE|
|LO|BR|GT|ET|OT|GT|GT|ET|OT|GT|LE|
|LO|GT|ET|BT|GT|  |  |ET|ET|BT|LE|
|LO|GT|  |ET|  |  |GT|ET|BR|GT|LE|
|  |  |GT|BT|GT|  |ET|BT|GT|CR|LE|
|LO|OT|GT|ET|CR|ET|BT|ET|OT|GT|LE|
|LO|ET|GT|BT|  |GT|  |ET|ET|BT|LE|
|CR|ST|BR|  |  |PT|  |  |ET|GT|LE|
|  |  |  |  |GR|ET|OT|BT|GT|ET|LE|
|  |  |  |  |  |LS|LS|LS|LS|LS|  |

"""

def is_dsl_valid(dsl):
    if dsl.count("|ST|") != 1:
        return False
    if dsl.count("|VT|") == 0:
        return False
    lines = dsl.splitlines()
    lines = [l for l in lines if l]
    pipe_counts = [line.count("|") for line in lines]
    for count in pipe_counts:
        if count != pipe_counts[0]:
            return False
    
    return True

tile_type_dict = {"VT": VictoryTile,
                  "ET": EnemyTile,
                  "OT": OtherTile,
                  "ST": StartTile,
                  "BT": BoringTile,
                  "GT": GuitaTile,
                  "PT": PolirrubroTile,
                  "MT": MenemTile,
                  "LE": LimiteEste,
                  "LO": LimiteOeste,
                  "LS": LimiteSur,
                  "LN": LimiteNorte,
                  "IT": ItemTile,
                  "CT": ChurroTile,
                  "CR": ChoriRoom,
                  "BR": BirraRoom,
                  "GR": GitanaRoom,
                  "  ": None}

world_map = []

start_tile_location = None

def parse_world_dsl():
    if not is_dsl_valid(world_dsl):
        raise SyntaxError("DSL inválida")
    
    dsl_lines = world_dsl.splitlines()
    dsl_lines = [x for x in dsl_lines if x]
    
    for y, dsl_row in enumerate(dsl_lines):
        row = []
        dsl_cells = dsl_row.split("|")
        dsl_cells = [c for c in dsl_cells if c]
        for x, dsl_cell in enumerate(dsl_cells):
            tile_type = tile_type_dict[dsl_cell]
            if tile_type == StartTile:
                global start_tile_location
                start_tile_location = x, y
            row.append(tile_type(x, y) if tile_type else None)
        
        world_map.append(row)

def tile_at(x, y):
    if x < 0 or y < 0:
        return None
    try:
        return world_map[y][x]
    except IndexError:
        return None